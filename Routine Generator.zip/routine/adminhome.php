<?php 
	include 'inc/header.php';
?>

<table border = 1 cellpadding = "30">
	<tr>
		<th>Teacher Initial</th>
		<th>Tearcher Name</th>
		<th>Credit Taken</th>
	</tr>
	<tr>
		<td>n/a n/a n/a n/a n/a</td>
		<td>n/a n/a n/a n/a n/a</td>
		<td>n/a n/a n/a n/a n/a</td>
	</tr>
	<tr>
		<td>n/a n/a n/a n/a n/a</td>
		<td>n/a n/a n/a n/a n/a</td>
		<td>n/a n/a n/a n/a n/a</td>
	</tr>
	<tr>
		<td>n/a n/a n/a n/a n/a</td>
		<td>n/a n/a n/a n/a n/a</td>
		<td>n/a n/a n/a n/a n/a</td>
	</tr>
</table>

<?php include 'inc/footer.php'; ?>